package com.example.chargespeed

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.chargespeed.databinding.ActivityMainBinding
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var peakPowerW = 0.0

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = update(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        update(registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)))
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(receiver)
    }

    private fun update(intent: Intent?) {
        if (intent == null) return
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val mv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        val temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
        val health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
        val tech = intent.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: getString(R.string.unknown)
        val percent = if (scale > 0 && level >= 0) level * 100 / scale else 0
        val voltage = mv / 1000.0
        val microAmps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) else 0
        val milliAmps = microAmps / 1000.0
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val watts = if (charging && milliAmps > 0) voltage * milliAmps / 1000.0 else 0.0
        if (watts > peakPowerW) peakPowerW = watts

        binding.powerText.text = String.format(Locale.US, "%.2f W", watts)
        binding.statusText.text = when (status) {
            BatteryManager.BATTERY_STATUS_CHARGING -> getString(R.string.charging)
            BatteryManager.BATTERY_STATUS_FULL -> getString(R.string.full)
            BatteryManager.BATTERY_STATUS_DISCHARGING -> getString(R.string.discharging)
            else -> getString(R.string.not_charging)
        }
        binding.batteryText.text = getString(R.string.battery_level) + ": " + percent + "%"
        binding.currentText.text = getString(R.string.current) + ": " + String.format(Locale.US, "%.0f mA", milliAmps)
        binding.voltageText.text = getString(R.string.voltage) + ": " + String.format(Locale.US, "%.3f V", voltage)
        binding.temperatureText.text = getString(R.string.temperature) + ": " + String.format(Locale.US, "%.1f°C", temp / 10.0)
        binding.healthText.text = getString(R.string.health) + ": " + healthName(health)
        binding.technologyText.text = getString(R.string.technology) + ": " + tech
        binding.pluggedText.text = getString(R.string.plugged) + ": " + pluggedName(plugged)
        binding.peakText.text = getString(R.string.history) + ": " + String.format(Locale.US, "%.2f W", peakPowerW)
    }

    private fun pluggedName(p: Int) = when (p) {
        BatteryManager.BATTERY_PLUGGED_AC -> getString(R.string.ac)
        BatteryManager.BATTERY_PLUGGED_USB -> getString(R.string.usb)
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> getString(R.string.wireless)
        BatteryManager.BATTERY_PLUGGED_DOCK -> getString(R.string.dock)
        else -> getString(R.string.unknown)
    }

    private fun healthName(h: Int) = when (h) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "جيدة"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "سخونة"
        BatteryManager.BATTERY_HEALTH_DEAD -> "تالفة"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "جهد زائد"
        BatteryManager.BATTERY_HEALTH_COLD -> "باردة"
        else -> getString(R.string.unknown)
    }
}
