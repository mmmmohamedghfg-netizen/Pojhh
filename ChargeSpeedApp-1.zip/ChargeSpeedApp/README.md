# ChargeSpeedApp

ارفع ملف ZIP فقط في المستودع، وأضف ملف البناء `.github/workflows/android.yml` بشكل منفصل.
