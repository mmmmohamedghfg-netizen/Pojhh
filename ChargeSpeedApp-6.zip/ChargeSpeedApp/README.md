# مراقب الشحن

تطبيق أندرويد لمراقبة سرعة الشحن مع رسم بياني مباشر.

## إصلاح القياس
- الجهد يُقرأ من EXTRA_VOLTAGE.
- التيار من BATTERY_PROPERTY_CURRENT_NOW أو sysfs.
- لا يوجد استخدام لـ BATTERY_PROPERTY_VOLTAGE_NOW لأنه غير موجود.
