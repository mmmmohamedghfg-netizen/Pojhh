package com.example.chargespeed

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Color
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.chargespeed.databinding.ActivityMainBinding
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: SharedPreferences

    private var charging = false
    private var sessionStart = 0L
    private var sessionEnergyWh = 0.0
    private var sessionPeakW = 0.0
    private var lastUpdate = 0L

    private var smoothedMilliAmps = 0.0
    private var smoothedVoltage = 0.0
    private var measurementSource = "BatteryManager"

    private val ioExecutor = Executors.newSingleThreadExecutor()

    @Volatile private var sysCurrentMicroAmps: Int? = null
    @Volatile private var sysVoltageMillivolts: Int? = null

    private val handler = Handler(Looper.getMainLooper())
    private val updater = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = getSharedPreferences("charge_stats", MODE_PRIVATE)
        binding.resetButton.setOnClickListener {
            prefs.edit().putInt("sessions", 0).apply()
            sessionStart = 0L
            sessionEnergyWh = 0.0
            sessionPeakW = 0.0
            refresh()
        }

        ContextCompat.registerReceiver(
            this,
            receiver,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        refresh()
    }

    override fun onResume() {
        super.onResume()
        lastUpdate = System.currentTimeMillis()
        handler.post(updater)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(updater)
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(receiver)
        ioExecutor.shutdown()
    }

    private fun refresh() {
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return

        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
        val health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
        val tech = intent.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: getString(R.string.unknown)

        val percent = if (scale > 0 && level >= 0) level * 100 / scale else 0

        var microAmps = 0
        var voltageMillivolts = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val bm = getSystemService(BatteryManager::class.java)
            if (bm != null) {
                microAmps = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
            }
        }

        val invalid = Int.MIN_VALUE
        var usedSysfs = false

        if (microAmps == 0 || microAmps == invalid) {
            sysCurrentMicroAmps?.let {
                microAmps = it
                usedSysfs = true
            }
        }

        if (voltageMillivolts == 0 || voltageMillivolts == invalid) {
            sysVoltageMillivolts?.let {
                voltageMillivolts = it
                usedSysfs = true
            }
        }

        measurementSource = if (usedSysfs) "sysfs" else "BatteryManager"

        val safeMicroAmps = if (microAmps == invalid) 0 else microAmps
        val safeVoltageMillivolts = if (voltageMillivolts == invalid) 0 else voltageMillivolts

        val rawMilliAmps = kotlin.math.abs(safeMicroAmps.toLong()) / 1000.0
        val rawVoltage = safeVoltageMillivolts / 1000.0

        val nowCharging = status == BatteryManager.BATTERY_STATUS_CHARGING && plugged != 0

        if (!nowCharging) {
            smoothedMilliAmps = 0.0
        } else if (rawMilliAmps > 0) {
            smoothedMilliAmps = ChargeMath.smooth(smoothedMilliAmps, rawMilliAmps)
        }

        if (rawVoltage > 0) {
            smoothedVoltage = ChargeMath.smooth(smoothedVoltage, rawVoltage)
        }

        val watts = if (nowCharging) smoothedVoltage * smoothedMilliAmps / 1000.0 else 0.0

        if (nowCharging && !charging) startSession()
        if (!nowCharging && charging) endSession()
        charging = nowCharging

        if (charging) {
            val now = System.currentTimeMillis()
            if (lastUpdate > 0) {
                val elapsedMs = (now - lastUpdate).coerceIn(0L, 2000L)
                val hours = elapsedMs / 3600000.0
                sessionEnergyWh += watts * hours
            }
            lastUpdate = now
            if (watts > sessionPeakW) sessionPeakW = watts
        } else {
            lastUpdate = 0L
        }

        val elapsedMin = if (charging && sessionStart > 0)
            (System.currentTimeMillis() - sessionStart) / 60000.0 else 0.0
        val avgW = if (elapsedMin > 0) sessionEnergyWh / (elapsedMin / 60.0) else 0.0

        binding.powerText.text = String.format(Locale.US, "%.2f W", watts)
        binding.batteryProgress.progress = percent
        binding.batteryText.text = getString(R.string.battery_level) + ": " + percent + "%"
        binding.chargeChart.addValue(watts.toFloat())

        val mode = when {
            !charging -> getString(R.string.not_charging)
            watts >= 18 -> getString(R.string.very_fast)
            watts >= 10 -> getString(R.string.fast)
            else -> getString(R.string.normal)
        }
        binding.modeText.text = mode
        binding.modeText.setTextColor(
            when {
                !charging -> Color.parseColor("#9AA4B2")
                watts >= 18 -> Color.parseColor("#00E676")
                watts >= 10 -> Color.parseColor("#FFB300")
                else -> Color.parseColor("#8AB4F8")
            }
        )

        binding.sessionTimeText.text = getString(R.string.session_time) + ": " + ChargeMath.formatDuration(elapsedMin)
        binding.sessionEnergyText.text = getString(R.string.session_energy) + ": " +
                String.format(Locale.US, "%.2f Wh", sessionEnergyWh)
        binding.sessionAvgText.text = getString(R.string.session_avg) + ": " +
                String.format(Locale.US, "%.2f W", avgW)
        binding.peakText.text = getString(R.string.peak) + ": " +
                String.format(Locale.US, "%.2f W", sessionPeakW)
        binding.sessionsText.text = getString(R.string.sessions) + ": " + prefs.getInt("sessions", 0)

        binding.currentText.text = getString(R.string.current) + ": " +
                String.format(Locale.US, "%.0f mA", smoothedMilliAmps)
        binding.voltageText.text = getString(R.string.voltage) + ": " +
                String.format(Locale.US, "%.3f V", smoothedVoltage)
        binding.temperatureText.text = getString(R.string.temperature) + ": " +
                String.format(Locale.US, "%.1f°C", temp / 10.0)
        binding.healthText.text = getString(R.string.health) + ": " + healthName(health)
        binding.technologyText.text = getString(R.string.technology) + ": " + tech
        binding.pluggedText.text = getString(R.string.plugged) + ": " + pluggedName(plugged)
        binding.measurementText.text = getString(R.string.measurement) + ": " + measurementSource

        readSysfsAsync()
    }

    private fun readSysfsAsync() {
        ioExecutor.execute {
            val current = readSysfs("/sys/class/power_supply/battery/current_now")
            val voltage = readSysfs("/sys/class/power_supply/battery/voltage_now")
            if (current != null) sysCurrentMicroAmps = current
            if (voltage != null) sysVoltageMillivolts = voltage
        }
    }

    private fun readSysfs(path: String): Int? {
        return try {
            File(path).readText().trim().toIntOrNull()
        } catch (e: Exception) {
            null
        }
    }

    private fun startSession() {
        sessionStart = System.currentTimeMillis()
        sessionEnergyWh = 0.0
        sessionPeakW = 0.0
        lastUpdate = System.currentTimeMillis()
        val sessions = prefs.getInt("sessions", 0) + 1
        prefs.edit().putInt("sessions", sessions).apply()
    }

    private fun endSession() {
        sessionStart = 0L
        sessionEnergyWh = 0.0
        sessionPeakW = 0.0
        lastUpdate = 0L
    }

    private fun pluggedName(p: Int) = when (p) {
        BatteryManager.BATTERY_PLUGGED_AC -> getString(R.string.ac)
        BatteryManager.BATTERY_PLUGGED_USB -> getString(R.string.usb)
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> getString(R.string.wireless)
        BatteryManager.BATTERY_PLUGGED_DOCK -> getString(R.string.dock)
        else -> getString(R.string.unknown)
    }

    private fun healthName(h: Int) = when (h) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "جيدة"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "سخونة"
        BatteryManager.BATTERY_HEALTH_DEAD -> "تالفة"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "جهد زائد"
        BatteryManager.BATTERY_HEALTH_COLD -> "باردة"
        else -> getString(R.string.unknown)
    }
}
