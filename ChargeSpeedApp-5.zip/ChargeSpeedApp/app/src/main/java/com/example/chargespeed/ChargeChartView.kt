package com.example.chargespeed

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import java.util.Locale

class ChargeChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val values = ArrayDeque<Float>()
    private val maxPoints = 60

    private val linePath = Path()
    private val fillPath = Path()

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF4F8CFF.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 6f
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x334F8CFF
        style = Paint.Style.FILL
    }

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x22FFFFFF
        strokeWidth = 2f
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF9AA4B2.toInt()
        textSize = resources.displayMetrics.scaledDensity * 14f
    }

    fun addValue(value: Float) {
        values.addLast(value)
        while (values.size > maxPoints) values.removeFirst()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val padding = 60f

        linePath.reset()
        fillPath.reset()

        for (i in 0..4) {
            val y = padding + (h - padding * 2) * i / 4f
            canvas.drawLine(0f, y, w, y, gridPaint)
        }

        if (values.isEmpty()) {
            canvas.drawText(context.getString(R.string.no_data), padding, h / 2f, textPaint)
            return
        }

        val max = (values.maxOrNull() ?: 1f).coerceAtLeast(1f)
        val stepX = if (values.size > 1) w / (values.size - 1) else w

        values.forEachIndexed { index, value ->
            val x = index * stepX
            val y = h - padding - (value / max) * (h - padding * 2)
            if (index == 0) linePath.moveTo(x, y) else linePath.lineTo(x, y)
        }

        fillPath.set(linePath)
        fillPath.lineTo(w, h)
        fillPath.lineTo(0f, h)
        fillPath.close()

        canvas.drawPath(fillPath, fillPaint)
        canvas.drawPath(linePath, linePaint)

        canvas.drawText(
            String.format(Locale.US, "%.1f W", max),
            padding,
            padding - 10f,
            textPaint
        )
    }
}
