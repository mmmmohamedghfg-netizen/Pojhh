package com.example.chargespeed

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Color
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.example.chargespeed.databinding.ActivityMainBinding
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: SharedPreferences

    private var charging = false
    private var sessionStart = 0L
    private var sessionEnergyWh = 0.0
    private var sessionPeakW = 0.0
    private var lastUpdate = 0L
    private var lastPercent = -1

    private val handler = Handler(Looper.getMainLooper())
    private val updater = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = getSharedPreferences("charge_stats", MODE_PRIVATE)
        binding.resetButton.setOnClickListener { resetStats() }

        registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        refresh()
    }

    override fun onResume() {
        super.onResume()
        handler.post(updater)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(updater)
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(receiver)
    }

    private fun refresh() {
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return

        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val mv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        val temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
        val health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
        val tech = intent.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: getString(R.string.unknown)

        val percent = if (scale > 0 && level >= 0) level * 100 / scale else 0
        val voltage = mv / 1000.0

        val bm = getSystemService(BatteryManager::class.java)
        val microAmps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) else 0

        val milliAmps = kotlin.math.abs(microAmps) / 1000.0
        val nowCharging = status == BatteryManager.BATTERY_STATUS_CHARGING && plugged != 0
        val watts = if (nowCharging) voltage * milliAmps / 1000.0 else 0.0

        if (nowCharging && !charging) startSession(percent)
        if (!nowCharging && charging) endSession()

        charging = nowCharging

        if (charging) {
            val now = System.currentTimeMillis()
            if (lastUpdate > 0) {
                val hours = (now - lastUpdate) / 3600000.0
                sessionEnergyWh += watts * hours
            }
            lastUpdate = now
            if (watts > sessionPeakW) sessionPeakW = watts
        } else {
            lastUpdate = 0L
        }

        val elapsedMin = if (charging && sessionStart > 0) (System.currentTimeMillis() - sessionStart) / 60000.0 else 0.0
        val avgW = if (elapsedMin > 0) sessionEnergyWh * 1000.0 / (elapsedMin / 60.0) / 1000.0 * 1000.0 else 0.0
        val avg = if (elapsedMin > 0) sessionEnergyWh / (elapsedMin / 60.0) else 0.0

        binding.powerText.text = String.format(Locale.US, "%.2f W", watts)
        binding.batteryProgress.progress = percent
        binding.batteryText.text = getString(R.string.battery_level) + ": " + percent + "%"

        val mode = when {
            !charging -> getString(R.string.not_charging)
            watts >= 18 -> getString(R.string.very_fast)
            watts >= 10 -> getString(R.string.fast)
            else -> getString(R.string.normal)
        }
        binding.modeText.text = mode
        binding.modeText.setTextColor(
            when {
                !charging -> Color.parseColor("#9AA4B2")
                watts >= 18 -> Color.parseColor("#00E676")
                watts >= 10 -> Color.parseColor("#FFB300")
                else -> Color.parseColor("#8AB4F8")
            }
        )

        binding.sessionTimeText.text = getString(R.string.session_time) + ": " + formatDuration(elapsedMin)
        binding.sessionEnergyText.text = getString(R.string.session_energy) + ": " +
                String.format(Locale.US, "%.2f Wh", sessionEnergyWh)
        binding.sessionAvgText.text = getString(R.string.session_avg) + ": " +
                String.format(Locale.US, "%.2f W", avg)
        binding.peakText.text = getString(R.string.peak) + ": " +
                String.format(Locale.US, "%.2f W", sessionPeakW)
        binding.sessionsText.text = getString(R.string.sessions) + ": " + prefs.getInt("sessions", 0)

        binding.currentText.text = getString(R.string.current) + ": " +
                String.format(Locale.US, "%.0f mA", milliAmps)
        binding.voltageText.text = getString(R.string.voltage) + ": " +
                String.format(Locale.US, "%.3f V", voltage)
        binding.temperatureText.text = getString(R.string.temperature) + ": " +
                String.format(Locale.US, "%.1f°C", temp / 10.0)
        binding.healthText.text = getString(R.string.health) + ": " + healthName(health)
        binding.technologyText.text = getString(R.string.technology) + ": " + tech
        binding.pluggedText.text = getString(R.string.plugged) + ": " + pluggedName(plugged)
    }

    private fun startSession(percent: Int) {
        sessionStart = System.currentTimeMillis()
        sessionEnergyWh = 0.0
        sessionPeakW = 0.0
        lastUpdate = System.currentTimeMillis()
        lastPercent = percent
        val sessions = prefs.getInt("sessions", 0) + 1
        prefs.edit().putInt("sessions", sessions).apply()
    }

    private fun endSession() {
        sessionStart = 0L
        sessionEnergyWh = 0.0
        sessionPeakW = 0.0
        lastUpdate = 0L
    }

    private fun resetStats() {
        prefs.edit().putInt("sessions", 0).apply()
        sessionStart = 0L
        sessionEnergyWh = 0.0
        sessionPeakW = 0.0
        refresh()
    }

    private fun formatDuration(minutes: Double): String {
        val total = minutes.toLong()
        val h = total / 60
        val m = total % 60
        return String.format(Locale.US, "%02d:%02d", h, m)
    }

    private fun pluggedName(p: Int) = when (p) {
        BatteryManager.BATTERY_PLUGGED_AC -> getString(R.string.ac)
        BatteryManager.BATTERY_PLUGGED_USB -> getString(R.string.usb)
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> getString(R.string.wireless)
        BatteryManager.BATTERY_PLUGGED_DOCK -> getString(R.string.dock)
        else -> getString(R.string.unknown)
    }

    private fun healthName(h: Int) = when (h) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "جيدة"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "سخونة"
        BatteryManager.BATTERY_HEALTH_DEAD -> "تالفة"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "جهد زائد"
        BatteryManager.BATTERY_HEALTH_COLD -> "باردة"
        else -> getString(R.string.unknown)
    }
}
